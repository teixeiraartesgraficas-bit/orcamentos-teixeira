# Orçamentos Teixeira (app Android)

App de orçamentos da Teixeira Artes Gráficas: Papel, Vinil, Lonas, Têxtil e Brindes.
O código da app está em `www/index.html`. O projeto usa Capacitor para a embrulhar numa app Android.

Este projeto ainda não foi compilado. Siga uma das duas opções.

## Opção A: compilar no computador (Android Studio)

1. Instale o Node.js (versão 20 ou superior), o JDK 21 e o Android Studio.
2. Numa janela de comandos, dentro desta pasta:
   - `npm install`
   - `npx cap add android`
   - `npx cap sync android`
   - `npx cap open android`
3. No Android Studio: menu Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O ficheiro fica em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Opção B: compilar no GitHub, sem instalar nada

1. Crie um repositório no GitHub e carregue o conteúdo desta pasta para a ramificação `main`.
2. No separador Actions, execute "Compilar APK" (ou espere que corra sozinho).
3. No fim, descarregue o ficheiro `orcamentos-teixeira-apk` e extraia o `app-debug.apk`.

## Instalar no telemóvel

Copie o `app-debug.apk` para o telemóvel e abra-o. O Android pede para permitir a instalação de aplicações de fontes desconhecidas. É um APK de teste (debug). Para publicar na Google Play é preciso um APK/AAB assinado.

## Logótipo e ícone

- O logótipo da Teixeira já está incluído na app. No ecrã Preços pode trocá-lo por outro ficheiro.
- O ícone da app está em `assets/icon.png`. Depois de `npx cap add android`, corra `npx @capacitor/assets generate --android` para o aplicar (a opção B já faz isto sozinha).

## Notas

- Os preços incluídos são exemplos. Edite-os no ecrã Preços da app.
- Os orçamentos ficam guardados no próprio telemóvel.
- Os tipos de letra vêm da Internet. Sem ligação, a app usa tipos de letra do sistema e funciona na mesma.
